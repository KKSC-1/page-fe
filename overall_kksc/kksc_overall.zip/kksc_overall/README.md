# kksc_overall

A Pen created on CodePen.io. Original URL: [https://codepen.io/rjmdpkwh-the-reactor/pen/ZEdYprL](https://codepen.io/rjmdpkwh-the-reactor/pen/ZEdYprL).

